import RPi.GPIO as GPIO
import time
import threading
import subprocess as sp
from NEOPIXELS import apa102

GPIO.setmode( GPIO.BCM )
GPIO.setwarnings( 0 )

clock_pin = 14
data_pin = 15
switch = 18
led = 21
shift_clock_pin = 5
latch_clock_pin = 6
data_pin_shuif = 13

GPIO.setup( shift_clock_pin, GPIO.OUT )
GPIO.setup( latch_clock_pin, GPIO.OUT )
GPIO.setup( data_pin_shuif, GPIO.OUT )
GPIO.setup(switch, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setup(clock_pin, GPIO.OUT)
GPIO.setup(data_pin, GPIO.OUT)
GPIO.setup(led, GPIO.OUT)


def hc595(shift_clock_pin, latch_clock_pin, data_pin, value, delay):
   for i in range(8):
      if value % 2 == 1:
         GPIO.output(data_pin, GPIO.HIGH)
         GPIO.output(shift_clock_pin, GPIO.HIGH)
         time.sleep(delay)
         GPIO.output(shift_clock_pin, GPIO.LOW)

      else:
         GPIO.output(data_pin, GPIO.LOW)
         GPIO.output(shift_clock_pin, GPIO.HIGH)
         time.sleep(delay)
         GPIO.output(shift_clock_pin, GPIO.LOW)

      value = value // 2

   GPIO.output(latch_clock_pin, GPIO.HIGH)
   time.sleep(delay)
   GPIO.output(latch_clock_pin, GPIO.LOW)
   time.sleep(delay)

def off():
   result = []
   for i in range(8):
      result.append([0, 0, 0])
   return result

def check_button():
   aan = True
   while True:
      if GPIO.input(switch) and aan:
         extProc2 = sp.Popen(['python','PROJECT.py'])
         GPIO.output(led, GPIO.HIGH)
         aan = False
         time.sleep(1)
      elif GPIO.input(switch) and aan == False:
         sp.Popen.terminate(extProc2)
         apa102(clock_pin, data_pin, off(), 10)
         hc595(5,6,13,0,0.01)
         GPIO.output(led, GPIO.LOW)
         aan = True
         time.sleep(1)



button_thread = threading.Thread(target=check_button)
button_thread.start()