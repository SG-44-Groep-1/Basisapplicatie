import RPi.GPIO as GPIO
import time
import threading
from NEOPIXELS import walk
from wave import servo_pulse

sr04_trig = 24
sr04_echo = 23
switch = 18
clock_pin = 14
data_pin = 15
servo = 26

shift_clock_pin = 5
latch_clock_pin = 6
data_pin_shuif = 13

GPIO.setup( shift_clock_pin, GPIO.OUT )
GPIO.setup( latch_clock_pin, GPIO.OUT )
GPIO.setup( data_pin_shuif, GPIO.OUT )
GPIO.setup( sr04_trig, GPIO.OUT )
GPIO.setup(servo, GPIO.OUT)
GPIO.setup( sr04_echo, GPIO.IN, pull_up_down=GPIO.PUD_DOWN )
GPIO.setup(switch, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)
GPIO.setmode( GPIO.BCM )
GPIO.setwarnings( 0 )

def sr04( trig_pin, echo_pin ):
   """
   Return the distance in cm as measured by an SR04
   that is connected to the trig_pin and the echo_pin.
   These pins must have been configured as output and input.s
   """
   GPIO.output(sr04_trig, GPIO.HIGH)
   time.sleep(0.00001)
   GPIO.output(sr04_trig, GPIO.LOW)

   start_time = 0
   stop_time = 0

   while GPIO.input(sr04_echo) == False:
      pass
   start_time = time.time()
   while GPIO.input(sr04_echo):
      stop_time = time.time()

   time_elapsed = stop_time - start_time
   distance = (34300.0 * time_elapsed) / 2.0

   return distance

def schuif():
   def hc595( shift_clock_pin, latch_clock_pin, data_pin, value, delay ):
      for i in range(8):
         if value % 2 == 1:
            GPIO.output(data_pin, GPIO.HIGH)
            GPIO.output(shift_clock_pin, GPIO.HIGH)
            time.sleep(delay)
            GPIO.output(shift_clock_pin, GPIO.LOW)

         else:
            GPIO.output(data_pin, GPIO.LOW)
            GPIO.output(shift_clock_pin, GPIO.HIGH)
            time.sleep(delay)
            GPIO.output(shift_clock_pin, GPIO.LOW)

         value = value // 2

      GPIO.output(latch_clock_pin, GPIO.HIGH)
      time.sleep(delay)
      GPIO.output(latch_clock_pin, GPIO.LOW)
      time.sleep(delay)


   delay = 0.018

   binair = 0
   while 1:
      hc595(shift_clock_pin, latch_clock_pin, data_pin_shuif, binair, delay)
      binair += 1



shuif_thread = threading.Thread(target=schuif)
shuif_thread.start()
while True:
    distance = sr04(sr04_trig, sr04_echo)
    neo_thread = threading.Thread(target=walk(clock_pin, data_pin, distance))
    neo_thread.start()
    servo_thread = threading.Thread(target=servo_pulse(servo, distance))
    servo_thread.start()
    time.sleep(0.1)

