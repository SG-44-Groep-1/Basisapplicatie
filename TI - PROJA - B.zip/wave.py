import time
import RPi.GPIO as GPIO
GPIO_pin = 25
GPIO.setmode(GPIO.BCM)
GPIO.setup(GPIO_pin, GPIO.OUT)
GPIO.setwarnings(0)

def servo_pulse(pin_nr, position):
    """
    Send a servo pulse on the specified gpio pin
    that causes the servo to turn to the
    specified position, and then waits 20 ms.

    The position must be in the range 0 .. 100.
    For this range, the pulse must be
    in the range 0.5 ms .. 2.5 ms.

    Before this function is called,
    the gpio pin must have been configured as output.
    """
    position *= 2.5
    if position > 100:
        position = 100
    delay = (position*0.02)/1000 + 0.00046
    GPIO.output(pin_nr, GPIO.HIGH)
    time.sleep(delay)
    GPIO.output(pin_nr, GPIO.LOW)
    time.sleep(0.02)


# servo = 26
# GPIO.setup( servo, GPIO.OUT )
# while True:
#    servo_pulse(servo, 95)
#    time.sleep(1)
#    servo_pulse(servo, 80)
#    time.sleep(1)