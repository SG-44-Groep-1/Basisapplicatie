import time
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(0)


def apa102_send_bytes(clock_pin, data_pin, bytes):
    """
    zend de bytes naar de APA102 LED strip die is aangesloten op de clock_pin en data_pin
    """

    for byte in bytes:
        for i in range(8):
            if byte % 256 >= 128:
                GPIO.output(data_pin, GPIO.HIGH)
                GPIO.output(clock_pin, GPIO.HIGH)
                GPIO.output(clock_pin, GPIO.LOW)
            else:
                GPIO.output(data_pin, GPIO.LOW)
                GPIO.output(clock_pin, GPIO.HIGH)
                GPIO.output(clock_pin, GPIO.LOW)
            byte = byte * 2


def apa102(clock_pin, data_pin, colors, brightness):
    """
    zend de colors naar de APA102 LED strip die is aangesloten op de clock_pin en data_pin

    De colors moet een list zijn, met ieder list element een list van 3 integers,
    in de volgorde [ blauw, groen, rood ].
    Iedere kleur moet in de range 0..255 zijn, 0 voor uit, 255 voor vol aan.

    bv: colors = [ [ 0, 0, 0 ], [ 255, 255, 255 ], [ 128, 0, 0 ] ]
    zet de eerste LED uit, de tweede vol aan (wit) en de derde op blauw, halve strekte.
    """

    for i in range(32):
        GPIO.output(data_pin, GPIO.LOW)
        GPIO.output(clock_pin, GPIO.HIGH)
        GPIO.output(clock_pin, GPIO.LOW)
    for list in colors:
        apa102_send_bytes(clock_pin, data_pin, [224 + brightness])
        apa102_send_bytes(clock_pin, data_pin, list)
    for i in range(32):
        GPIO.output(data_pin, GPIO.HIGH)
        GPIO.output(clock_pin, GPIO.HIGH)
        GPIO.output(clock_pin, GPIO.LOW)

low = [0, 255, 0]

ish = [0, 255, 255]
mid = [0, 40, 255]
high = [0, 0, 255]


blue = [8, 0, 0]
green = [0, 255, 0]
red = [0, 0, 255]
white = [255, 255, 255]
off = [0, 0, 0]

def colors_left(color, count):
    result = []
    for i in range(4):
        result.append(off)
    for i in range(count):
        result.append(color)
    for i in range(4-count):
        result.append(off)
    return result

def colors_right(color, count):
    result = []
    for i in range(4 - count):
        result.append(off)
    for i in range(count):
        result.append(color)
    for i in range(4):
        result.append(off)
    return result

def led_off():
    result = []
    for i in range(8):
        result.append(off)
    return result
base = 5
def walk(clock_pin, data_pin, distance):
    GPIO.setup(clock_pin, GPIO.OUT)
    GPIO.setup(data_pin, GPIO.OUT)
    if distance <= base:
        apa102(clock_pin, data_pin, colors_right(high, 4), 10)
    elif distance <= base * 2:
        apa102(clock_pin, data_pin, colors_right(mid, 3), 10)
    elif base * 2 < distance <= base * 3:
        apa102(clock_pin, data_pin, colors_right(ish, 2), 10)
    elif base * 3 < distance <= base * 4:
        apa102(clock_pin, data_pin, colors_right(low, 1), 10)
    elif base * 4 < distance <= base * 5:
        apa102(clock_pin, data_pin, led_off(), 10)
    elif base * 5 < distance <= base * 6:
        apa102(clock_pin, data_pin, colors_left(low, 1), 10)
    elif base * 6 < distance <= base * 7:
        apa102(clock_pin, data_pin, colors_left(ish, 2), 10)
    elif base * 7 < distance < base * 8:
        apa102(clock_pin, data_pin, colors_left(mid, 3), 10)
    elif base * 8 < distance:
        apa102(clock_pin, data_pin, colors_left(high, 4), 10)



