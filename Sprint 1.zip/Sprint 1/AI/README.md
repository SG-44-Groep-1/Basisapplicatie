# Project B
In dit project maken we een grafische weergave die inzicht geeft in het gaming gedrag van jouw vrienden op het platform Steam, ondersteund door een netwerk waarbij gebruik gemaakt wordt van een RaspberryPi.

## Uitvoeren van de applicatie

Om de applicatie te laten werken is het installeren van Pycharm op uw computer nodig.
In Pycharm moet de bijgeleverde code gezet worden, als dit is gedaan moet de gebruiker
op de rechtermuisknop klikken en "Run" klikken. 

## SG-44 - Groep 1

Jasper - Vormer - AI/TI/CSC
```
voor-achternaam:      Jasper van der Post
studentnummer:        1777790
username:             BOT Arnold
```

Lucas - Brononderzoeker - BIM
```
voor-achternaam:      Lucas van der Holt
studentnummer:        1785077
username:             Surgicalsniper01
```

Damian - Plant - AI/TI/CSC
```
voor-achternaam:      Damian Brands
studentnummer:        1776677
username:             Bino
```

Tim - Bedrijfsman - AI/TI
```
voor-achternaam:      Tim Bolhoeve
studentnummer:        1789912
username:             Orange Juice
```

### Gemaakt met

* [Pycharm](https://www.jetbrains.com/pycharm/) - Voor het maken van de GUI
* [Steam](https://store.steampowered.com/) - Voor een lijst met spellen en vrienden

### Auteur

* **Tim Bolhoeve**
